README.txt

All written answers are in the Answers.txt file located in the same folder as this README.
All code is within the assign1 folder, separated into part 1 and part 2.
The code that has been added or modified has been commented with the convention "//Part X: Question Y"
So please use that to search for answers.

Thanks
