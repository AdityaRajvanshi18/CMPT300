/*************** YOU SHOULD NOT MODIFY ANYTHING IN THIS FILE ***************/
int run_smp0_tests(int argc, char **argv);
int main(int argc, char **argv);
